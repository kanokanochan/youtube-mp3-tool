#!/usr/bin/env python3
"""YouTube → MP3 変換ツール（Mac / Windows 共通）

    python3 server.py [--open] [--lan]

yt-dlp と ffmpeg を呼び出して MP3 を「ミュージック/YouTube-mp3」に保存する。
標準ライブラリのみで動く。Windows では必要な道具（yt-dlp / ffmpeg / deno）を
初回に bin/ へ自動ダウンロードする。

  --open  起動後にこのパソコンのブラウザで開く（起動済みなら開くだけ）
  --lan   同じ Wi-Fi 内の iPad・スマホ等からも接続できるようにする（既定はこのパソコン内のみ）
"""
import ipaddress
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
import webbrowser
import zipfile
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlparse

WINDOWS = os.name == "nt"
LAN = "--lan" in sys.argv
HOST, PORT = ("0.0.0.0" if LAN else "127.0.0.1"), 8790
BASE = Path(__file__).resolve().parent
BIN = BASE / "bin"
OUT_DIR = Path.home() / "Music" / "YouTube-mp3"
SHARED_DIR = OUT_DIR / "共有分"  # このパソコン以外（iPad 等）から変換されたものはこちらに入れる

ALLOWED_URL_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com",
    "music.youtube.com", "youtu.be",
}
LOCAL_HOST_HEADERS = {f"127.0.0.1:{PORT}", f"localhost:{PORT}"}
COOKIE_MAX_AGE = 60 * 60 * 24 * 365
CID_RE = re.compile(r"^[A-Za-z0-9_-]{16,40}$")

# yt-dlp の --audio-quality に渡す値
QUALITIES = {"best": "0", "320": "320K", "192": "192K", "128": "128K"}
MAX_PARALLEL = 2  # 同時に変換する本数（残りは待機）

# Windows 配布版が初回に自動で取りに行くもの: (コマンド名, URL, zip から取り出すファイル。None は exe 単体)
DOWNLOADS = [
    ("yt-dlp", "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe", None),
    ("ffmpeg", "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/"
               "ffmpeg-master-latest-win64-gpl.zip", ("ffmpeg.exe", "ffprobe.exe")),
    ("deno", "https://github.com/denoland/deno/releases/latest/download/"
             "deno-x86_64-pc-windows-msvc.zip", ("deno.exe",)),
]

# bin/（Windows 配布版）と Homebrew（Finder から起動すると PATH に入らない）を探せるようにする
os.environ["PATH"] = os.pathsep.join(
    [str(BIN), "/opt/homebrew/bin", "/usr/local/bin", os.environ.get("PATH", "")]
)

jobs = {}  # id -> dict
jobs_lock = threading.Lock()
slots = threading.Semaphore(MAX_PARALLEL)
setup = {"state": "working", "message": "準備中…"}  # state: working / ready / error


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # 実際には何も送らない
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


def share_url():
    """iPad・スマホで開く URL（--lan のときだけ）"""
    ip = lan_ip() if LAN else None
    return f"http://{ip}:{PORT}/" if ip else None


def fetch(url, dest, label):
    tmp = dest.with_name(dest.name + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "yt-mp3"})
    with urllib.request.urlopen(req, timeout=60) as r, tmp.open("wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while chunk := r.read(1 << 18):
            f.write(chunk)
            done += len(chunk)
            pct = f" {done * 100 // total}%" if total else ""
            setup["message"] = f"初回の準備中: {label} をダウンロードしています…{pct}"
    tmp.replace(dest)


def prepare():
    """変換に必要な道具をそろえる（Windows は不足分を自動ダウンロード）"""
    try:
        if WINDOWS:
            BIN.mkdir(exist_ok=True)
            had_ytdlp = (BIN / "yt-dlp.exe").exists()
            for cmd, url, members in DOWNLOADS:
                if shutil.which(cmd):
                    continue
                if members is None:
                    fetch(url, BIN / f"{cmd}.exe", cmd)
                    continue
                archive = BIN / f"{cmd}.zip"
                fetch(url, archive, cmd)
                setup["message"] = f"初回の準備中: {cmd} を展開しています…"
                with zipfile.ZipFile(archive) as zf:
                    for info in zf.infolist():
                        name = Path(info.filename).name
                        if name in members:
                            with zf.open(info) as src, (BIN / name).open("wb") as dst:
                                shutil.copyfileobj(src, dst)
                archive.unlink()
            if had_ytdlp:
                # YouTube 側の仕様変更に追従するため、起動のたびに yt-dlp を最新にする
                setup["message"] = "yt-dlp の更新を確認しています…"
                try:
                    subprocess.run([str(BIN / "yt-dlp.exe"), "-U"],
                                   capture_output=True, timeout=180)
                except (OSError, subprocess.TimeoutExpired):
                    pass
        if shutil.which("yt-dlp") and shutil.which("ffmpeg"):
            setup.update(state="ready", message="")
        else:
            setup.update(state="error",
                         message="yt-dlp / ffmpeg が見つかりません（Mac: brew install yt-dlp ffmpeg）")
    except Exception as e:
        setup.update(state="error",
                     message=f"準備に失敗しました（{e}）。インターネット接続を確認して、起動し直してください。")
    print("準備完了" if setup["state"] == "ready" else f"[!] {setup['message']}", flush=True)


def update(job_id, **fields):
    with jobs_lock:
        jobs[job_id].update(fields)


def clean_name(name):
    """ユーザー指定のファイル名から Mac / Windows で使えない文字を除く（空なら動画タイトルを使う）"""
    name = re.sub(r"\.mp3$", "", name.strip(), flags=re.IGNORECASE)
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
    return name.strip(" .")[:150]


def run_job(job_id, url, quality, name, out_dir):
    # 題名指定があればそれを、なければ動画タイトルをファイル名にする（% はテンプレート記号なのでエスケープ）
    stem = name.replace("%", "%%") if name else "%(title)s"
    cmd = [
        shutil.which("yt-dlp"),
        "--no-playlist", "--encoding", "utf-8",
        "-x", "--audio-format", "mp3", "--audio-quality", QUALITIES[quality],
        "--embed-metadata", "--embed-thumbnail",
        "--newline", "--progress", "--no-colors",
        "--progress-template", "download:PROG %(progress._percent_str)s",
        "--print", "pre_process:TITLE %(title)s",
        "--print", "after_move:FILE %(filepath)s",
        "-o", str(out_dir / f"{stem}.%(ext)s"),
        "--", url,
    ]
    errors = []
    with slots:
        started = time.time()
        update(job_id, status="downloading")
        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
            )
            for line in proc.stdout:
                line = line.strip()
                if line.startswith("PROG "):
                    try:
                        pct = float(line[5:].strip().rstrip("%"))
                    except ValueError:
                        continue
                    update(job_id, progress=pct,
                           status="converting" if pct >= 100 else "downloading")
                elif line.startswith("TITLE ") and not name:
                    update(job_id, title=line[6:])
                elif line.startswith("FILE "):
                    update(job_id, file=line[5:])
                elif line.startswith("ERROR:"):
                    errors.append(line[6:].strip())
            code = proc.wait()
        except Exception as e:  # yt-dlp を起動できなかった等
            update(job_id, status="error", error=str(e))
            return

    with jobs_lock:
        job = jobs[job_id]
        f = Path(job["file"]) if job.get("file") else None
        if code == 0 and not (f and f.exists()):
            # 出力の文字化け等でパスを読み取れなかったときは、いま出来た mp3 を探す
            fresh = [p for p in out_dir.glob("*.mp3") if p.stat().st_mtime >= started - 1]
            f = max(fresh, key=lambda p: p.stat().st_mtime, default=None)
        if code == 0 and f:
            job.update(status="done", progress=100.0, file=str(f), size=f.stat().st_size)
        else:
            job.update(status="error",
                       error=" / ".join(errors) or f"yt-dlp が終了コード {code} で失敗しました")


def reveal(path):
    """保存したファイルを Finder / エクスプローラーで選択表示する"""
    if WINDOWS:
        subprocess.Popen(f'explorer /select,"{path}"')
    else:
        subprocess.run(["open", "-R", str(path)])


def open_folder(path):
    if WINDOWS:
        os.startfile(path)
    else:
        subprocess.run(["open", str(path)])


def validate_url(url):
    try:
        p = urlparse(url)
    except ValueError:
        return False
    return p.scheme in ("http", "https") and (p.hostname or "").lower() in ALLOWED_URL_HOSTS


def public(job):
    out = {k: job.get(k) for k in
           ("id", "url", "title", "status", "progress", "error", "size", "quality")}
    out["filename"] = Path(job["file"]).name if job.get("file") else None
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if "/api/jobs" in str(args[0] if args else ""):  # ポーリングは記録しない
            return
        super().log_message(fmt, *args)

    def send_body(self, body, ctype, code=200):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, obj, code=200):
        self.send_body(json.dumps(obj, ensure_ascii=False).encode(),
                       "application/json; charset=utf-8", code)

    def cookies(self):
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie") or "")
        except CookieError:
            return {}
        return {k: m.value for k, m in jar.items()}

    def viewer(self):
        """閲覧者ID（ブラウザごとの Cookie）。変換リストを端末ごとに分けるために使う。"""
        cid = self.cookies().get("ytmp3_cid", "")
        return cid if CID_RE.match(cid) else None

    def request_ok(self):
        """よそのウェブページ経由の呼び出しを弾く（Host は localhost か IP アドレスのみ、Origin は同一のみ）"""
        host = self.headers.get("Host") or ""
        name = host.rsplit(":", 1)[0].strip("[]")
        try:
            ok = name == "localhost" or bool(ipaddress.ip_address(name))
        except ValueError:
            ok = False
        origin = self.headers.get("Origin")
        if ok and origin and urlparse(origin).netloc != host:
            ok = False
        if not ok:
            self.send_json({"error": "forbidden"}, 403)
        return ok

    def is_local(self):
        """ツールを動かしているパソコン自身のブラウザか（LAN 経由は False）"""
        return (self.client_address[0] in ("127.0.0.1", "::1")
                and self.headers.get("Host") in LOCAL_HOST_HEADERS
                and not self.headers.get("X-Forwarded-For"))

    def read_json(self):
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            return None
        try:
            n = int(self.headers.get("Content-Length") or 0)
            data = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return None
        return data if isinstance(data, dict) else None

    def do_HEAD(self):
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if not self.request_ok():
            return
        path = urlparse(self.path).path
        cid = self.viewer()
        if path == "/":
            body = (BASE / "index.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            if not cid:
                self.send_header("Set-Cookie", f"ytmp3_cid={secrets.token_urlsafe(16)}; Path=/; "
                                               f"Max-Age={COOKIE_MAX_AGE}; HttpOnly; SameSite=Lax")
            self.end_headers()
            self.wfile.write(body)
        elif not cid:
            self.send_json({"error": "ページを読み込み直してください"}, 403)
        elif path == "/api/jobs":
            with jobs_lock:
                mine = sorted((j for j in jobs.values() if j["owner"] == cid),
                              key=lambda j: j["created"], reverse=True)
                items = [public(j) for j in mine]
            local = self.is_local()
            self.send_json({"jobs": items, "setup": setup, "local": local,
                            "out_dir": str(OUT_DIR) if local else None,
                            "share_url": share_url() if local else None})
        elif path.startswith("/files/"):
            self.serve_file(path[len("/files/"):], cid)
        else:
            self.send_json({"error": "not found"}, 404)

    def serve_file(self, job_id, cid):
        with jobs_lock:
            job = jobs.get(job_id)
            f = Path(job["file"]) if job and job["owner"] == cid and job.get("file") else None
        if not f or not f.is_file():
            self.send_json({"error": "not found"}, 404)
            return
        self.send_response(200)
        self.send_header("Content-Type", "audio/mpeg")
        self.send_header("Content-Length", str(f.stat().st_size))
        self.send_header("Content-Disposition",
                         f"attachment; filename*=UTF-8''{quote(f.name)}")
        self.end_headers()
        with f.open("rb") as fh:
            shutil.copyfileobj(fh, self.wfile)

    def do_POST(self):
        path = urlparse(self.path).path
        data = self.read_json()  # 先に本文を読み切る（keep-alive のため）
        if not self.request_ok():
            return
        cid = self.viewer()
        if not cid:
            self.send_json({"error": "ページを読み込み直してください"}, 403)
            return
        if data is None:
            self.send_json({"error": "bad request"}, 400)
            return
        local = self.is_local()

        if path == "/api/convert":
            url = str(data.get("url") or "").strip()
            quality = str(data.get("quality") or "best")
            name = clean_name(str(data.get("name") or ""))
            if setup["state"] != "ready":
                self.send_json({"error": setup["message"]}, 503)
            elif not validate_url(url):
                self.send_json({"error": "YouTube のリンクを入力してください"}, 400)
            elif quality not in QUALITIES:
                self.send_json({"error": "音質の指定が不正です"}, 400)
            else:
                job_id = uuid.uuid4().hex
                out_dir = OUT_DIR if local else SHARED_DIR
                out_dir.mkdir(parents=True, exist_ok=True)
                with jobs_lock:
                    jobs[job_id] = {"id": job_id, "owner": cid, "url": url, "quality": quality,
                                    "title": name or None, "status": "queued", "progress": 0.0,
                                    "error": None, "file": None, "size": None,
                                    "created": time.time()}
                threading.Thread(target=run_job, args=(job_id, url, quality, name, out_dir),
                                 daemon=True).start()
                self.send_json({"id": job_id})
        elif path == "/api/reveal" and local:
            with jobs_lock:
                job = jobs.get(str(data.get("id")))
                f = job.get("file") if job and job["owner"] == cid else None
            if f and Path(f).exists():
                reveal(f)
                self.send_json({"ok": True})
            else:
                self.send_json({"error": "ファイルが見つかりません"}, 404)
        elif path == "/api/open-folder" and local:
            open_folder(OUT_DIR)
            self.send_json({"ok": True})
        else:
            self.send_json({"error": "not found"}, 404)


class Server(ThreadingHTTPServer):
    # Windows は再利用を許すと二重起動でも bind が通ってしまう
    allow_reuse_address = not WINDOWS


def main():
    for stream in (sys.stdout, sys.stderr):  # Windows のコンソールで表示できない文字があっても落ちないように
        stream.reconfigure(errors="replace")
    local_url = f"http://127.0.0.1:{PORT}/"
    try:
        server = Server((HOST, PORT), Handler)
    except OSError:
        # すでに起動している → ブラウザで開くだけ
        if "--open" in sys.argv:
            webbrowser.open(local_url)
            return
        raise
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print("YouTube → MP3 変換ツール（このウィンドウを閉じると終了します）")
    print(f"  保存先            : {OUT_DIR}")
    print(f"  このパソコンで開く: {local_url}")
    if LAN:
        print(f"  iPad・スマホで開く: {share_url() or '（Wi-Fi に接続されていません）'}")
    sys.stdout.flush()
    threading.Thread(target=prepare, daemon=True).start()
    if "--open" in sys.argv:
        threading.Timer(0.5, webbrowser.open, args=(local_url,)).start()
    server.serve_forever()


if __name__ == "__main__":
    main()
