#!/bin/bash
# ダブルクリックで起動（初回だけ専用の Python を自動で取得します）
cd "$(dirname "$0")/app" || exit 1
PY=runtime/python/bin/python3

if [ ! -x "$PY" ]; then
  case "$(uname -m)" in arm64) ARCH=aarch64 ;; *) ARCH=x86_64 ;; esac
  URL="https://github.com/astral-sh/python-build-standalone/releases/download/20261001/cpython-3.12.15%2B20261001-__ARCH__-apple-darwin-install_only_stripped.tar.gz"
  echo "初回の準備中: Python をダウンロードしています（約 25 MB）…"
  mkdir -p runtime
  if ! curl -L --fail --silent --show-error -o runtime/python.tar.gz "${URL/__ARCH__/$ARCH}" \
     || ! tar -xzf runtime/python.tar.gz -C runtime; then
    rm -rf runtime
    echo
    echo "準備に失敗しました。インターネット接続を確認して、もう一度起動してください。"
    read -n 1 -s -r -p "何かキーを押すと閉じます"
    exit 1
  fi
  rm -f runtime/python.tar.gz
fi

exec "$PY" server.py --open
