@echo off
setlocal
title YouTube to MP3
cd /d "%~dp0app"
if errorlevel 1 goto unzip
set "PY=runtime\python\python.exe"
if exist "%PY%" goto run

echo First-time setup: downloading Python runtime (about 11 MB)...
if not exist runtime\python mkdir runtime\python
curl.exe -L --fail --silent --show-error -o runtime\python.zip "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip"
if errorlevel 1 goto fail
tar.exe -xf runtime\python.zip -C runtime\python
if errorlevel 1 goto fail
del runtime\python.zip

:run
"%PY%" server.py --open
if errorlevel 1 pause
goto :eof

:unzip
echo Please extract the zip file first (right-click the zip, "Extract All"), then run this file again.
pause
goto :eof

:fail
echo.
echo Setup failed. Please check your internet connection and run this file again.
if exist runtime\python.zip del runtime\python.zip
if exist runtime\python rmdir /s /q runtime\python
pause
